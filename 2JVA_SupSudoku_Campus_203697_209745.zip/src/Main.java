import com.supinfo.window.Window;

public class Main {

	public static void main(String[] args) {
		
		Window Sudoku = new Window("SupSudoku");
		Sudoku.setVisible(true);

	}

}
